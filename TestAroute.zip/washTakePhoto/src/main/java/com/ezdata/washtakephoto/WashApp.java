package com.ezdata.washtakephoto;


import com.ezdata.commonlib.core.App;

public class WashApp extends App {

}

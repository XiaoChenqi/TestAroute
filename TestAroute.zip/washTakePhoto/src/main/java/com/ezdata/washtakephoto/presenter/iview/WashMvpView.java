package com.ezdata.washtakephoto.presenter.iview;

import com.ezdata.commonlib.core.mvp.MvpView;

public interface WashMvpView extends MvpView {
    /**
     * 负载量为空
     */
    void burdenNull();
}
